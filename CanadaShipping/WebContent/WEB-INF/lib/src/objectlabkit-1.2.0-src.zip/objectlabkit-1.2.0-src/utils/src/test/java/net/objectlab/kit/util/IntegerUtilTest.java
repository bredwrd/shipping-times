package net.objectlab.kit.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class IntegerUtilTest {

    @Test
    public void testIsNotZero() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsZero() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsNullOrZero() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsSameValue() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsNotSameValue() {
        fail("Not yet implemented");
    }

    @Test
    public void testSafeAdd() {
        fail("Not yet implemented");
    }

    @Test
    public void testSafeSignum() {
        fail("Not yet implemented");
    }

    @Test
    public void testSafeCompare() {
        fail("Not yet implemented");
    }

    @Test
    public void testAssign() {
        fail("Not yet implemented");
    }

    @Test
    public void testIsNotZeroOrNegative() {
        fail("Not yet implemented");
    }

}
