package net.objectlab.kit.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class ObjectUtilTest {

    @Test
    public void testEqualsIntegerInteger() {
        fail("Not yet implemented");
    }

    @Test
    public void testEqualsBigDecimalBigDecimal() {
        fail("Not yet implemented");
    }

    @Test
    public void testEqualsObjectObject() {
        fail("Not yet implemented");
    }

    @Test
    public void testEqualsAny() {
        fail("Not yet implemented");
    }

    @Test
    public void testEqualsAll() {
        fail("Not yet implemented");
    }

    @Test
    public void testNotEqualsAny() {
        fail("Not yet implemented");
    }

    @Test
    public void testAnyNull() {
        fail("Not yet implemented");
    }

    @Test
    public void testAllNull() {
        fail("Not yet implemented");
    }

    @Test
    public void testAtLeastOneNotNull() {
        fail("Not yet implemented");
    }

    @Test
    public void testNoneNull() {
        fail("Not yet implemented");
    }

}
