/**
 * 
 */
package net.objectlab.kit.util;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author Benoit
 *
 */
public class AverageTest {

    /**
     * Test method for {@link net.objectlab.kit.util.Average#Average()}.
     */
    @Test
    public void testAverage() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#Average(java.math.BigDecimal)}.
     */
    @Test
    public void testAverageBigDecimal() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#Average(int)}.
     */
    @Test
    public void testAverageInt() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#add(java.math.BigDecimal)}.
     */
    @Test
    public void testAdd() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#getTotal()}.
     */
    @Test
    public void testGetTotal() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#getDataPoints()}.
     */
    @Test
    public void testGetDataPoints() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#getAverage()}.
     */
    @Test
    public void testGetAverage() {
        fail("Not yet implemented");
    }

    /**
     * Test method for {@link net.objectlab.kit.util.Average#toString()}.
     */
    @Test
    public void testToString() {
        fail("Not yet implemented");
    }

}
