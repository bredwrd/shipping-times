package net.objectlab.kit.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class TripletTest {

    @Test
    public void testHashCode() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetElement1() {
        fail("Not yet implemented");
    }

    @Test
    public void testCreate() {
        fail("Not yet implemented");
    }

    @Test
    public void testTriplet() {
        fail("Not yet implemented");
    }

    @Test
    public void testSetElement1() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetElement2() {
        fail("Not yet implemented");
    }

    @Test
    public void testSetElement2() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetElement3() {
        fail("Not yet implemented");
    }

    @Test
    public void testSetElement3() {
        fail("Not yet implemented");
    }

    @Test
    public void testEqualsObject() {
        fail("Not yet implemented");
    }

    @Test
    public void testToString() {
        fail("Not yet implemented");
    }

}
