package net.objectlab.kit.util;

import static org.junit.Assert.*;

import org.junit.Test;

public class WeightedAverageTest {

    @Test
    public void testGetTotal() {
        fail("Not yet implemented");
    }

    @Test
    public void testAdd() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetWeightedAverage() {
        fail("Not yet implemented");
    }

    @Test
    public void testGetCount() {
        fail("Not yet implemented");
    }

}
